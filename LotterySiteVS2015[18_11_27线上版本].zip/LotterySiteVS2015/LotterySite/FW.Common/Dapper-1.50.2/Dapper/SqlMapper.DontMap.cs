﻿namespace Dapper
{
    partial class SqlMapper
    {
        /// <summary>
        /// Dummy type for excluding from multi-map
        /// </summary>
        class DontMap { }
    }
}
