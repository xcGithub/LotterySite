﻿


部署问题：
1.无法加载 DLL“SQLite.Interop.dll”: 找不到指定的模块。 (异常来自 HRESULT:0x8007007E)。
	应用程序池4.0 
	集成 
	允许运行32程序集 	
	SQLite.Interop.dll 不要引用直接放到 /bin/x86 目录下