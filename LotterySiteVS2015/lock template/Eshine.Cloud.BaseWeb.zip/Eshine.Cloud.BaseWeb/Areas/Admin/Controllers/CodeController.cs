﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Eshine.Cloud.BaseWeb.Areas.Admin.Controllers
{
    public class CodeController : Controller
    {
        //
        // GET: /Admin/Code/

        public ActionResult Index()
        {
            return View();
        }

    }
}
